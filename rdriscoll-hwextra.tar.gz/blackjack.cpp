#include "blackjack.h"
#include "ui_blackjack.h"


BlackJack::BlackJack(QWidget *parent) :
    QMainWindow(parent),
    UI(new Ui::BlackJack)
{
    UI->setupUi(this);

    m_playerwins = 0;
    m_dealerswins = 0;
    m_playershand = new Hand(this);
    m_dealershand = new Hand(this);
    m_deck = new Deck();

    this->setWindowTitle("Blackjack");

    QWidget *centralWidget = new QWidget(this);

    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

    QHBoxLayout *topLayout = new QHBoxLayout();
    QLabel *cardsLeftLabel = new QLabel("Cards:", centralWidget);
    m_CARDSLEFT = new QSpinBox(centralWidget);
    m_CARDSLEFT->setValue(52);
    m_CARDSLEFT->setReadOnly(true);

    topLayout->addWidget(cardsLeftLabel);
    topLayout->addWidget(m_CARDSLEFT);


    m_PLAYERSHANDVIEW = new HandView("Player's Hand:",m_playershand,true,centralWidget);
    m_DEALERSHANDVIEW = new HandView("Dealer's Hand:",m_dealershand,false,centralWidget);

    QHBoxLayout *handsLayout = new QHBoxLayout();

    handsLayout->addWidget(m_DEALERSHANDVIEW);
    handsLayout->addWidget(m_PLAYERSHANDVIEW);

    mainLayout->addLayout(topLayout);
    mainLayout->addSpacing(10);
    mainLayout->addLayout(handsLayout);

    QMenuBar *menuBar = new QMenuBar(this);
    this->setMenuBar(menuBar);
    menuBar->setMinimumSize(50,50);
    menuBar->setVisible(true);
    QMenu *gameMenu = new QMenu("BlackJack", this);

    QActionGroup *actionGroup = new QActionGroup(this);
    actionGroup->setExclusive(true);

    ACTION_NEWGAME = new QAction("NEW GAME",this);
    ACTION_DEALHAND = new QAction("DEAL HAND",this);
    ACTION_SHUFFLEDECK = new QAction("SHUFFLE DECK",this);
    ACTION_HITME = new QAction("HIT ME",this);
    ACTION_STAY = new QAction("STAY",this);
    ACTION_QUIT = new QAction("QUIT",this);

    actionGroup->addAction(ACTION_NEWGAME);
    gameMenu->addAction(ACTION_NEWGAME);
    connect(ACTION_NEWGAME, SIGNAL(triggered()), this, SLOT(NEWGAME()));

    actionGroup->addAction(ACTION_DEALHAND);
    gameMenu->addAction(ACTION_DEALHAND);
    connect(ACTION_DEALHAND, SIGNAL(triggered()), this, SLOT(DEALHAND()));

    actionGroup->addAction(ACTION_SHUFFLEDECK);
    gameMenu->addAction(ACTION_SHUFFLEDECK);
    connect(ACTION_SHUFFLEDECK, SIGNAL(triggered()), this, SLOT(SHUFFLEDECK()));

    actionGroup->addAction(ACTION_HITME);
    gameMenu->addAction(ACTION_HITME);
    connect(ACTION_HITME, SIGNAL(triggered()), this, SLOT(HITME()));

    actionGroup->addAction(ACTION_STAY);
    gameMenu->addAction(ACTION_STAY);
    connect(ACTION_STAY, SIGNAL(triggered()), this, SLOT(STAY()));

    actionGroup->addAction(ACTION_QUIT);
    gameMenu->addAction(ACTION_QUIT);
    connect(ACTION_QUIT, SIGNAL(triggered()), this, SLOT(QUIT()));

    menuBar->addMenu(gameMenu);

    QToolBar *toolbar = new QToolBar(this);
    this->addToolBar(Qt::RightToolBarArea, toolbar);
    toolbar->addActions(actionGroup->actions());

    centralWidget->setLayout(mainLayout);
    setCentralWidget(centralWidget);

    SETACTIONS(true,false,false,false,false,true);

}

BlackJack::~BlackJack()
{
    delete UI;
}

void BlackJack::SETACTIONS(bool NEWGAME, bool DEALHAND, bool SHUFFLEDECK, bool HITME, bool STAY, bool QUIT)
{
    ACTION_NEWGAME->setEnabled(NEWGAME);
    ACTION_DEALHAND->setEnabled(DEALHAND && m_deck->cardsLeft() != 0);
    ACTION_SHUFFLEDECK->setEnabled(SHUFFLEDECK);
    ACTION_HITME->setEnabled(HITME);
    ACTION_STAY->setEnabled(STAY);
    ACTION_QUIT->setEnabled(QUIT);
}

void BlackJack::NEWGAME()
{
    m_DEALERSHANDVIEW->setHandCardVisibility(false);
    m_deck->shuffle();
    m_playershand->discardHand();
    m_dealershand->discardHand();
    SETACTIONS(false,true,true,false,false,true);
}

void BlackJack::DetermineOutcome()
{
    if(m_playershand->m_cards.size() >=5 && m_playershand->getValue() != -1) {
        thePlayerWon();
    }else if (m_dealershand->m_cards.size() >=5 && m_dealershand->getValue() != -1) {
        theDealerWon();
    }else if(m_playershand->getValue() > m_dealershand->getValue()) {
        thePlayerWon();
    } else {
        theDealerWon();
    }
}

QString BlackJack::GETSCORES()
{
    QStringList qsl;
    qsl << "Player's Score: " + ((m_playershand->getValue()!=-1)?QString::number(m_playershand->getValue()):"bust");
    qsl << "Dealer's Score: " + ((m_dealershand->getValue()!=-1)?QString::number(m_dealershand->getValue()):"bust");
    qsl << "";
    qsl << "Player's Wins: " + QString::number(m_playerwins);
    qsl << "Dealer's Wins: " + QString::number(m_dealerswins);
    return qsl.join("\n");
}

void BlackJack::DEALHAND()
{
    m_DEALERSHANDVIEW->setHandCardVisibility(false);
    m_playershand->discardHand();
    m_dealershand->discardHand();

    for(int i = 0; i < 2; i++) {
        *m_playershand << m_deck->pick();
        updateCardsLeft();

    }
    for(int i = 0; i < 2; i++) {
        *m_dealershand << m_deck->pick();
        updateCardsLeft();
    }
    SETACTIONS(false,false,false,true,true,false);
}

void BlackJack::SHUFFLEDECK()
{
    m_deck->shuffle();
    updateCardsLeft();
    SETACTIONS(true,false,true,false,false,true);
}

void BlackJack::HITME()
{

    if(m_deck->m_cards.isEmpty()) return;

    *m_playershand << m_deck->pick();
    updateCardsLeft();

    if(m_playershand->getValue() == -1) {
        theDealerWon();
    }else if(m_playershand->m_cards.size() == 5) {
        DetermineOutcome();
    }
}

void BlackJack::STAY()
{
    while(m_dealershand->getValue() <= 18 && m_dealershand->getValue() != -1 && m_dealershand->getValue() <= m_playershand->getValue() && !m_deck->m_cards.isEmpty() && m_dealershand->m_cards.size() < 5) {
        *m_dealershand << m_deck->pick();
        updateCardsLeft();
    }
    DetermineOutcome();
}

void BlackJack::QUIT()
{
    QApplication::quit();
}

void BlackJack::SETACTIONS(bool b)
{
    SETACTIONS(b,b,b,b,b,b);
}

void BlackJack::updateCardsLeft()
{

    int cardsleft = m_deck->cardsLeft();
    m_CARDSLEFT->setValue(cardsleft);
}

void BlackJack::thePlayerWon()
{
    m_playerwins++;
    m_DEALERSHANDVIEW->setHandCardVisibility(true);
    QString scores = GETSCORES();
    QMessageBox::information(this, "Player has won!", scores, QMessageBox::Ok);
    endCurrentRound();
}

void BlackJack::theDealerWon()
{
    m_dealerswins++;
    m_DEALERSHANDVIEW->setHandCardVisibility(true);
    QString scores = GETSCORES();
    QMessageBox::information(this, "Dealer has won!", scores, QMessageBox::Ok);
    endCurrentRound();

}

void BlackJack::endCurrentRound()
{
    if (m_deck->cardsLeft() == 0) {
        SETACTIONS(false,false,true,false,false,true);
    }else {
        SETACTIONS(true,true,false,false,false,true);
    }
    m_PLAYERSHANDVIEW->updateViewScore(m_playerwins);
    m_DEALERSHANDVIEW->updateViewScore(m_dealerswins);
}


