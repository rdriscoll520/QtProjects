#include "deck.h"

Deck::Deck()
{
    reset();
}

int Deck::cardsLeft()
{
    return m_cards.size();
}

void Deck::shuffle()
{
    reset();
    qsrand(time(0));

    for(int i = m_cards.size() - 1; i > 0; --i)
    {
        int j = qrand() % (i + 1);
        Card* temp = m_cards[i];
        m_cards[i] = m_cards[j];
        m_cards[j] = temp;
    }
    m_shuffled = true;
}


void Deck::reset()
{
    m_cards.clear();
    for(int suit = 1; suit <= 4; suit++) {
        for(int face = 1; face <= 13; face++) {
            m_cards << new Card(face, suit);
        }
    }
    m_shuffled = false;
}

Card* Deck::pick()
{
    if (m_cards.isEmpty()) return nullptr;
    Card* card = m_cards.takeFirst();
    return card;
}

bool Deck::isShuffled()
{
    return m_shuffled;
}

