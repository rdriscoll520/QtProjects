#ifndef DECK_H
#define DECK_H

#include <QObject>
#include "card.h"

class Deck : public QObject
{
    Q_OBJECT

public:
    QList<Card*> m_cards;
    Deck();
    int cardsLeft();
    void shuffle();
    void reset();
    Card* pick();
    bool isShuffled();
    bool m_shuffled;
};

#endif // DECK_H
