#ifndef CARD_H
#define CARD_H

#include <QString>
#include <QStringList>

class Card
{

public:
    Card(int faceNbr, int suitNbr);
    QString getFilePath();
    int getValue();
    bool isAce();
private:
    int m_FaceNbr;
    int m_suitNbr;
    static QStringList m_faceFileName;
    static QStringList m_suitFileName;
};

#endif // CARD_H
