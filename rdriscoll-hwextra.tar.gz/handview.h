#ifndef HANDVIEW_H
#define HANDVIEW_H

#include <QWidget>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QVector>
#include "hand.h"

class HandView : public QWidget
{
    Q_OBJECT
public:
    explicit HandView(QString name, Hand *hand, bool show, QWidget *parent = nullptr);
    void setHandCardVisibility(bool boolean);
    void updateViewScore(int i);
private:
    QString m_name;
    Hand* m_Hand;
    bool m_visibility;
    QLabel* m_Label;
    QVector<QLabel*> m_cardimages;
public slots:
    void updateHandDisplay();
};

#endif // HANDVIEW_H
