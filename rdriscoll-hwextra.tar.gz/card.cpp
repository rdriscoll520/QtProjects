#include "card.h"

QStringList Card::m_faceFileName = QStringList{"a", "2", "3", "4", "5", "6", "7", "8", "9", "t", "j", "q", "k"};
QStringList Card::m_suitFileName = QStringList{"h", "d", "c", "s"};

Card::Card(int faceNbr, int suitNbr) : m_FaceNbr(faceNbr), m_suitNbr(suitNbr)
{
}

QString Card::getFilePath()
{
    return QString(":/images/images/" + m_faceFileName[m_FaceNbr-1] + m_suitFileName[m_suitNbr-1] + ".png");
}

int Card::getValue()
{
    if(m_FaceNbr = 11 | m_FaceNbr == 12 | m_FaceNbr == 13) return 10;
    else return m_FaceNbr;
}

bool Card::isAce()
{
    return m_FaceNbr == 1;
}
