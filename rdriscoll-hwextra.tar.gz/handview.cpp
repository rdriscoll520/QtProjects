#include "handview.h"



HandView::HandView(QString name, Hand *hand, bool show, QWidget *parent) : QWidget(parent), m_name(name), m_Hand(hand), m_visibility(show)
{
    m_Label = new QLabel(m_name, this);

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(m_Label);

    QVBoxLayout* cardsLayout = new QVBoxLayout();
    mainLayout->addLayout(cardsLayout);

    for(int i = 0; i < 5; i++) {
      QLabel* cardLabel = new QLabel(this);
      cardLabel->setFixedSize(72,96);
      cardLabel->setStyleSheet("border: 1px solid black;");
      cardLabel->setVisible(false);
      m_cardimages.append(cardLabel);
      cardsLayout->addWidget(cardLabel);
    }

    connect(m_Hand, SIGNAL(handChanged()), this, SLOT(updateHandDisplay()));
    setLayout(mainLayout);
}

void HandView::setHandCardVisibility(bool boolean)
{
    m_visibility = boolean;
    updateHandDisplay();
}

void HandView::updateViewScore(int i)
{
    m_Label->setText(QString(m_name + ": " + QString::number(i)));
}

void HandView::updateHandDisplay()
{
    for(int i = 0; i < m_cardimages.size(); i++) {
        if(i < m_Hand->m_cards.size()) {
            Card* card = m_Hand->m_cards.at(i);
            if(m_visibility) {
                m_cardimages[i]->setPixmap(QPixmap(card->getFilePath()));
            }else {
                m_cardimages[i]->setPixmap(QPixmap(":/images/images/cb.png"));
            }
            m_cardimages[i]->setVisible(true);
        }else {
            m_cardimages[i]->setVisible(false);
        }
    }
}

