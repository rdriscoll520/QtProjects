#include "hand.h"
#include "card.h"

Hand::Hand(QObject *parent) : QObject(parent)
{
}

Hand &Hand::operator <<(Card *card)
{
    m_cards.append(card);
    emit handChanged();
    return *this;
}

int Hand::getValue()
{
    int aces = numAces();
    int value = 0;
    for(Card* c : m_cards) {
        value += c->getValue();
    }

    while (aces > 0 && value + 10 <= 21) {
        value += 10;
        aces--;
    }

    if(value > 21) return -1;

    return value;
}

int Hand::numAces()
{
    int value = 0;
    for(Card* c : m_cards) {
        if (c->isAce()) value++;
    }
    return value;
}

void Hand::discardHand()
{
    m_cards.clear();
    emit handChanged();
}
