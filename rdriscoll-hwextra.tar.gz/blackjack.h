#ifndef BLACKJACK_H
#define BLACKJACK_H

#include <QObject>
#include <QMainWindow>
#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QSpinBox>
#include <QTimer>
#include <QEventLoop>
#include <QMessageBox>

#include "hand.h"
#include "card.h"
#include "deck.h"
#include "handview.h"


namespace Ui {
class BlackJack;
}

class BlackJack : public QMainWindow
{
    Q_OBJECT

public:
    explicit BlackJack(QWidget *parent = 0);
    ~BlackJack();

private: //model
    Hand* m_playershand;
    Hand* m_dealershand;
    Deck* m_deck;
    int m_playerwins;
    int m_dealerswins;
    void updateCardsLeft();
    void thePlayerWon();
    void theDealerWon();
    void DetermineOutcome();
    void endCurrentRound();
public slots:
    void NEWGAME();
    void DEALHAND();
    void SHUFFLEDECK();
    void HITME();
    void STAY();
    void QUIT();
private: //ui
    Ui::BlackJack *UI;
    HandView *m_PLAYERSHANDVIEW;
    HandView *m_DEALERSHANDVIEW;
    QSpinBox *m_CARDSLEFT;
    void SETACTIONS(bool b);
    void SETACTIONS(bool NEWGAME, bool DEALHAND, bool SHUFFLEDECK, bool HITME, bool STAY, bool QUIT);
    QAction* ACTION_NEWGAME;
    QAction* ACTION_DEALHAND;
    QAction* ACTION_SHUFFLEDECK;
    QAction* ACTION_HITME;
    QAction* ACTION_STAY;
    QAction* ACTION_QUIT;
    QString GETSCORES();


};

#endif // BlackJack_H
