#ifndef HAND_H
#define HAND_H

#include "card.h"

class Hand : public QObject
{
    Q_OBJECT

public:
    QList<Card*> m_cards;
    Hand(QObject *parent = nullptr);
    Hand &operator <<(Card* card);
    int getValue();
    int numAces();
    void discardHand();
signals:
    void handChanged();
public slots:

};

#endif // HAND_H
