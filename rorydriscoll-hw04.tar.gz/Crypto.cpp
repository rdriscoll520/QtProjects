#include "Crypto.h"
#include <QTextStream>
#include <QVector>
#include <QString>
#include <stdlib.h>
#include <iostream>
Crypto::Crypto(ushort key, QString opseq)
{
    m_Key = key;
    m_OpSequence = opseq;
}

int myRand(int min, int max) {
    int range = max - min + 1;
    int randomNum = random() % range + min;
    return randomNum;
}

QVector<int> Crypto::randomPerm(int n) {
    srandom(m_Key); //creates seed
    QVector<int> vector(n);
    for(int i=0; i<n; i++) {
        vector[i] = i;
    }
    for(int i=n-1; i>0; i--) {
        int j = limitedRand(i);
        qSwap(vector[i], vector[j]);
    }

    return vector;
}


QString Crypto::shift(const QString& str)
{
    srandom(m_Key);
    QString code = "";
    for(int i = 0; i<str.length(); i++) {
        QChar c = str[i];
        int randomNum = limitedRand(128);
        int newValue = c.unicode() + (randomNum % 128);
        if (newValue > 65535) {
            newValue = newValue % 65536;
        }
        code.append(QChar(newValue));
    }
    return code;
}

QString Crypto::unshift(const QString &str)
{
    srandom(m_Key);
    QString code = "";
    for(QChar c : str) {
        int randomNum = limitedRand(128);
        QChar originalVal = QChar(c.unicode() + (-1*randomNum) % 128);
        code.append(QChar(originalVal));
    }
    return code;
}

QString Crypto::permute(const QString &str) {
    QString permutation = "";
    srandom(m_Key);
    QVector<int> order = randomPerm(str.length());
    for(int i = 0; i<str.length(); i++) {
        permutation.append(str[order[i]]);
    }
    return permutation;
}

QString Crypto::unpermute(const QString& str)
{
    srandom(m_Key);
    QString unpermutation = "";
    QVector<int> order = randomPerm(str.length());
    for(int i = 0; i<str.length(); i++) {
        unpermutation.append(str[order.indexOf(i)]);

    }
    return unpermutation;
}

int Crypto::limitedRand(int max)
{
    return random() % max;
}

QString Crypto::encrypt(const QString &str)
{
    QString list = str;
    for(QChar c : m_OpSequence) {
        if(c == 's') {
            list = shift(list);
        } else if(c == 'p') {
            list = permute(list);
        }
    }
    return list;

}

QString Crypto::decrypt(const QString &str)
{
    QString list = str;
    for(int i =m_OpSequence.length(); i>0; i--) {
        QChar c = m_OpSequence[i-1];
        if(c == 'p') {
            list = unpermute(list);
        }
        else if(c == 's') {
            list = unshift(list);
        }
    }

    return list;
}
