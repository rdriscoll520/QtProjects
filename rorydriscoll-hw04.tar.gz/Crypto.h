#ifndef CRYPTO_H
#define CRYPTO_H
#include <QString>
#include <QTextStream>
#include <QVector>

class Crypto {
private:
    ushort m_Key;
    QString m_OpSequence;
    ushort m_CharSetSize;
    QVector<int> m_Perm;

    QString shift(const QString& str);
    QString unshift(const QString& str);
    QString permute(const QString& str);
    QString unpermute(const QString& str);
    static int limitedRand(int max);
    QVector<int> randomPerm(int n);

public:
    Crypto(ushort key, QString opseq);
    QString encrypt(const QString& str);
    QString decrypt(const QString& str);

};
#endif
