#ifndef CARDHAND_H
#define CARDHAND_H
#include <QList>
#include "Card.h"

class CardHand : public QList<Card>{
public:
    int getValue();
    QString toString();
};

#endif
