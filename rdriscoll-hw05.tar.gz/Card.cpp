#include "Card.h"

QStringList Card::s_Faces = QStringList{"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"};
QStringList Card::s_Suits = QStringList{"Hearts", "Diamonds", "Clubs", "Spades"};

Card::Card(int faceNbr, int suitNbr) {
    m_FaceNbr = faceNbr;
    m_SuitNbr = suitNbr;
}

QString Card::toString() {
    return this->getFace() + " of " + this->getSuit();
}

QString Card::getFace() {
    return s_Faces.at(m_FaceNbr);
}

QString Card::getSuit() {
    return s_Suits.at(m_SuitNbr);
}

int Card::getValue() {
    if(m_FaceNbr == 0) {
        return 4;
    } else if(m_FaceNbr == 12) {
        return 3;
    } else if(m_FaceNbr == 11) {
        return 2;
    } else if(m_FaceNbr == 10) {
        return 1;
    } else {
        return 0;
    }
}
