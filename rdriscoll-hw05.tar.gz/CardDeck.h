#ifndef CARDDECK_H
#define CARDDECK_H
#include "CardHand.h"
#include "Card.h"

class CardDeck : public QList<Card> {
    public:
        CardDeck();
        CardHand deal(int handSize);
        QString toString();
        int getCardsLeft() const;
        void restoreDeck();
};

#endif
