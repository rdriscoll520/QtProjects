#include <cstdlib>
#include "CardDeck.h"

CardDeck::CardDeck() {
    restoreDeck();
}

CardHand CardDeck::deal(int handSize) {
    CardHand hand = CardHand();
    for(int i=0; i<handSize; i++) {
        int randomCard = random() % this->size();
        hand << this->at(randomCard);
        this->removeAt(randomCard);
    }
    return hand;
}

QString CardDeck::toString() {
    QString deck;
    for(Card card : *this) {
        deck += card.toString();
    }
    return deck;
}

int CardDeck::getCardsLeft() const {
    return this->size();
}

void CardDeck::restoreDeck() {
    this->clear();

    for(int suitNbr = 0; suitNbr < 4; suitNbr++) {
        for(int faceNbr=0; faceNbr< 13; faceNbr++) {
            this->append(Card(faceNbr, suitNbr)); //new
        }
    }
}
