#ifndef PUZZLEMODEL_H
#define PUZZLEMODEL_H

#include <QObject>

class PuzzleModel : public QObject
{
    Q_OBJECT
private:
    QList<int> m_Positions;
    int m_Rows;
    int m_Cols;
public:
    explicit PuzzleModel(QObject *parent = nullptr);
    int value(int r, int c);
    bool slide(int tilenum);
    bool neighboring(int r, int c);
    int getRow();
    int getColumn();

    void shuffle();
    bool complete();


signals:
    void gridChanged();
    void gameWon();

public slots:
};

#endif // PUZZLEMODEL_H
