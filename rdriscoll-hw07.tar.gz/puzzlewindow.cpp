#include "puzzlewindow.h"
#include "ui_puzzlewindow.h"
#include "puzzlemodel.h"
#include "puzzleview.h"
PuzzleWindow::PuzzleWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PuzzleWindow)
{
    ui->setupUi(this);

    PuzzleModel *model = new PuzzleModel(this); //create
    PuzzleView *view = new PuzzleView(model, this);
    setCentralWidget(view);
}

PuzzleWindow::~PuzzleWindow()
{
    delete ui;
}
