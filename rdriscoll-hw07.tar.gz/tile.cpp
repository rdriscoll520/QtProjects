#include "tile.h"


Tile::Tile(int tileNumber)
{
    m_Number = tileNumber;
}
