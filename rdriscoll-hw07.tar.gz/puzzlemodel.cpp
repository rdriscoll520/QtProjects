#include "puzzlemodel.h"
#include "QVector"

PuzzleModel::PuzzleModel(QObject *parent) : QObject(parent)
{
    for(int i=0; i<=15;i++) {
        m_Positions.append(i);
    }
    m_Rows = 4;
    m_Cols = 4;
}


int PuzzleModel::value(int r, int c)
{
    if (r >= 0 && r < m_Rows && c >= 0 && c < m_Cols)
    {
        int index = r * m_Cols + c;

        // check
        if (index >= 0 && index < m_Positions.size()) {
            return m_Positions[index];
        }
    } else {
        return -1;
    }
}

bool PuzzleModel::slide(int tilenum)
{
    int tnIndex = m_Positions.indexOf(tilenum);
    int zIndex = m_Positions.indexOf(0);

    if(tnIndex < 0 || zIndex <0) return false;

    int tnRow = tnIndex/m_Cols;
    int tnColumn = tnIndex%m_Cols;

    if(neighboring(tnRow, tnColumn)) {
        qSwap(m_Positions[tnIndex], m_Positions[zIndex]);
        emit gridChanged();
        if(complete()) {
            emit gameWon();
        }
        return true;
    } else {
        return false;
    }
}

bool PuzzleModel::neighboring(int r, int c)
{
    int zero = m_Positions.indexOf(0);
    int row2 = zero/m_Cols;
    int col2 = zero%m_Cols;

    return (qAbs(row2-r) == 1 && c == col2) || (qAbs(c - col2) == 1 && row2 == r);
}

int PuzzleModel::getRow()
{
    return m_Rows;
}

int PuzzleModel::getColumn()
{
    return m_Cols;
}

void PuzzleModel::shuffle()
{
    qsrand(time(nullptr));

    for(int i=0; i<3; i++) {
        QVector<int> validMoves;
        int emptyI = m_Positions.indexOf(0);
        int eR = emptyI / m_Cols;
        int eC = emptyI % m_Cols;

        if(eR > 0) {
            validMoves.append(value(eR -1, eC));
        }
        if(eR< m_Rows -1) {
            validMoves.append(value(eR + 1, eC));
        }
        if(eC > 0) {
            validMoves.append(value(eR, eC - 1));
        }

        if(eC < m_Cols - 1) {
            validMoves.append(value(eR, eC + 1));
        }

        if(!validMoves.isEmpty()) {
            int move = validMoves[qrand() % validMoves.size()];
            slide(move);
        }
        validMoves.clear();
    }

}

bool PuzzleModel::complete()
{
    for(int i = 0; i < m_Positions.size(); i++) {
        if(m_Positions[i] != i) {
            return false;
        }
    }
    return true;
}


