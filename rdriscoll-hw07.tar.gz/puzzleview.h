#ifndef PUZZLEVIEW_H
#define PUZZLEVIEW_H

#include <QWidget>
#include "puzzlemodel.h"
#include <QGridLayout>
#include <QButtonGroup>
#include <QAbstractButton>

class PuzzleView : public QWidget
{
    Q_OBJECT
private:
    PuzzleModel* m_Model;
    QGridLayout* m_Layout;
    QButtonGroup* m_Buttons;

    void setupLayout();
    void createButtons();

public:
    explicit PuzzleView(PuzzleModel *model, QWidget *parent = nullptr);


public slots:
    void tryToSlide(QAbstractButton* button);
    void tryToSlide();
    void refresh();

    void tryToSuffle();
    void tryToQuit();
    void Win();
};

#endif // PUZZLEVIEW_H
