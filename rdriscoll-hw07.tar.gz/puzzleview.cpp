#include "puzzleview.h"
#include "tile.h"
#include <QAbstractButton>
#include <QMessageBox>
#include <QCoreApplication>

PuzzleView::PuzzleView(PuzzleModel *model, QWidget *parent) : QWidget(parent)
{
    m_Model = model;
    setupLayout();
    createButtons();
    refresh();
    connect(m_Model, SIGNAL(gridChanged()), this, SLOT(refresh()));
    connect(m_Model, SIGNAL(gameWon()), this, SLOT(Win()));
}

void PuzzleView::setupLayout()
{
    m_Layout = new QGridLayout(this);
    m_Layout->setSpacing(1);
    setLayout(m_Layout);
}

void PuzzleView::createButtons()
{
    m_Buttons = new QButtonGroup(this);
    //iterate
    for(int r=0; r<m_Model->getRow(); r++) {
        for(int c=0; c<m_Model->getColumn(); c++) {
            int value = m_Model->value(r, c); //adding value and buttons
            Tile *button = new Tile(value);
            button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            m_Layout->addWidget(button, r, c);
            m_Buttons->addButton(button, r* m_Model->getColumn() + c);
            connect(button, SIGNAL(clicked(bool)), this, SLOT(tryToSlide())); //make work
        }

    }
    QSpacerItem* spacer = new QSpacerItem(10,1,QSizePolicy::Expanding, QSizePolicy::Minimum);
    m_Layout->addItem(spacer, 0, 4, 1,1);

    QPushButton* shuffle = new QPushButton("Shuffle");
    m_Layout->addWidget(shuffle, 2, 5);
    connect(shuffle, SIGNAL(clicked()), this, SLOT(tryToSuffle()));

    QPushButton* quit = new QPushButton("Quit");
    m_Layout->addWidget(quit, 3, 5);
    connect(quit, SIGNAL(clicked()), this, SLOT(tryToQuit()));
}

void PuzzleView::tryToSlide() {
    QAbstractButton *button = qobject_cast<QAbstractButton*> (sender());
    tryToSlide(button);
}

void PuzzleView::tryToSlide(QAbstractButton *button)
{
    int num = button->text().toInt();
    m_Model->slide(num);
}

void PuzzleView::refresh()
{
    for(int i=0; i<m_Model->getRow() * m_Model->getColumn(); i++) {
            int r = i / m_Model->getColumn();
            int c = i % m_Model->getColumn();
            QAbstractButton *tile = m_Buttons->button(i);
                if(tile) { // Check if the tile is valid
                int value = m_Model->value(r,c);
                QString string = QString::number(value);
                tile->setText(string);
                tile->setVisible(value != 0);
//            }
        }
    }
}

void PuzzleView::tryToSuffle()
{
   QMessageBox::StandardButton answer;
   answer = QMessageBox::question(this, "Shuffle", "Do you want to shuffle?", QMessageBox::No | QMessageBox::Yes);

   if(answer == QMessageBox::Yes) {
       m_Model->shuffle();
       refresh();
   }
}

void PuzzleView::tryToQuit()
{
    QMessageBox::StandardButton answer;
    answer = QMessageBox::question(this, "Quit", "Do you want to quit?", QMessageBox::No | QMessageBox::Yes);

    if(answer == QMessageBox::Yes) {
        QCoreApplication::quit();
    }
}

void PuzzleView::Win()
{
    QMessageBox::StandardButton answer;
    answer = QMessageBox::question(this, "good job! you won!!!", "Do you want to play again?", QMessageBox::No | QMessageBox::Yes);

    if(answer == QMessageBox::Yes) {
        m_Model->shuffle();
        refresh();
    } else {
        QCoreApplication::quit();
    }
}
