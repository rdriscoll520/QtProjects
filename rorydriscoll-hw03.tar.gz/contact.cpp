#include "contact.h"
#include <QString>


Contact::Contact (int cat, QString firstN, QString lastN, QString streetAdd, QString zip, QString cty, QString phoneNum) {
	category = cat;
	firstName = firstN;
	lastName = lastN;
	streetAddress = streetAdd;
	zipCode = zip;
	city = cty;
	phoneNumber = phoneNum;

}

bool Contact::operator ==(const Contact& other) const{
    return this->getPhoneNumber() == other.getPhoneNumber();
}
QString Contact::toString() {

return QString::number(category) + " " + firstName + " " + lastName + " " + streetAddress + " " + zipCode + " " + city + " " + phoneNumber;

}

int Contact::getCategory() const { return category; }
QString Contact::getFirstName() const { return firstName; }
QString Contact::getLastName() const { return lastName; }
QString Contact::getStreetAddress() const { return streetAddress; }
QString Contact::getZipCode() const { return zipCode; }
QString Contact::getCity() const { return city; }
QString Contact::getPhoneNumber() const { return phoneNumber; }


