#include "contact.h"
#include "contactFactory.h"
#include "contactList.h"
#include <QTextStream>
#include <QStringList>
#include <QTime>

int main() {
    QTime time = QTime::currentTime();
    qsrand((uint)time.msec());

    QTextStream cout(stdout);
	ContactList list;
	ContactFactory cf;
	for(int i = 0; i<100; i++) {
		list.add(cf.createRandomContact());
	}

    int random = qrand() % 100;

    cout << "Removing index at " << random << endl;

	list.remove(list[random]);

    int category = qrand() % 10 + 1;
	
    cout << "Phone list for category : " << category << " " <<endl;
    QStringList qsl = list.getPhoneList(category);
	for(QString str : qsl) {
		cout << str + "\n";
	}

    cout << "Mailing list for category " << category << " " << endl;
    qsl = list.getMailingList(category);
    for(QString str : qsl) {
        cout << str + "\n";
    }

}
