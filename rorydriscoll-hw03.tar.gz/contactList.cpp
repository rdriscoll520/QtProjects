#include "contact.h"
#include "contactList.h"
#include <QStringList>
#include <QString>
#include <QList>
ContactList::ContactList() : QList<Contact>() {

}

void ContactList::add(Contact c) {
	this->append(c);
}

void ContactList::remove(Contact c) {
	int index = this->indexOf(c);

	if(index != -1) {

	this->removeAt(index);

	}
}

QStringList ContactList::getPhoneList(int category) {
    QStringList list;
    for(int i = 0; i < this->size(); i++) {
        Contact contact = this->at(i);
        if(contact.getCategory() == category) {
            list.append(contact.getFirstName() + " " + contact.getLastName() + "\t" + contact.getPhoneNumber());
        }
    }
    return list;
}

QStringList ContactList::getMailingList(int category) {
    QStringList list;
    for(int i = 0; i < this->size(); i++) {
        Contact contact = this->at(i);
        if(contact.getCategory() == category) {
            QString string = contact.getStreetAddress() + " " + contact.getZipCode() + " " + contact.getCity();
            list.append(string);
        }
    }
    return list;
}


