#ifndef CONTACT_H
#define CONTACT_H

#include <QString>
class Contact {

private:
	int category;
	QString firstName;
	QString lastName;
	QString streetAddress;
	QString zipCode;
	QString city;
	QString phoneNumber;

public:
	Contact(int cat, QString firstN, QString lastN, QString streetAdd, QString zip, QString cty, QString phoneNum);
	QString toString();

    bool operator==(const Contact& other) const;

	//getters in case
    int getCategory() const;
    QString getFirstName() const;
    QString getLastName() const;
    QString getStreetAddress() const;
    QString getZipCode() const;
    QString getCity() const;
    QString getPhoneNumber() const;
};

#endif

