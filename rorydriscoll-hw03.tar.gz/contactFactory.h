#ifndef CONTACTFACTORY_H
#define CONTACTFACTORY_H

#include "contact.h"
#include <QString>
#include <QStringList>


class ContactFactory {
private:
	static inline QStringList firstNames  = {
	"Liam", "Noah", "Oliver", "Elijah", "William",
    "James", "Benjamin", "Lucas", "Henry", "Alexander",
    "Mason", "Michael", "Ethan", "Daniel", "Jacob",
    "Logan", "Jackson", "Levi", "Sebastian", "Mateo",
    "Jack", "Owen", "Theodore", "Aiden", "Samuel",
    "Joseph", "John", "David", "Wyatt", "Matthew",
    "Luke", "Asher", "Carter", "Julian", "Grayson",
    "Leo", "Jayden", "Gabriel", "Isaac", "Lincoln",
    "Anthony", "Hudson", "Dylan", "Ezra", "Thomas",
    "Charles", "Christopher", "Jaxon", "Maverick", "Josiah"
	};

	static inline QStringList lastNames = {
	"Smith", "Johnson", "Williams", "Brown", "Jones",
    "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
    "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
    "Thomas", "Taylor", "Moore", "Jackson", "Martin",
    "Lee", "Perez", "Thompson", "White", "Harris",
    "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson",
    "Walker", "Young", "Allen", "King", "Wright",
    "Scott", "Torres", "Nguyen", "Hill", "Flores",
    "Green", "Adams", "Nelson", "Baker", "Hall",
    "Rivera", "Campbell", "Mitchell", "Carter", "Roberts"
	};

	static inline QStringList streetAddresses = {
	"Main Street", "Elm Street", "Maple Avenue", "Oak Street", "Pine Street",
    "Birch Street", "Cedar Avenue", "Cherry Street", "Aspen Way", "Willow Street",
    "Spruce Street", "Mahogany Boulevard", "Walnut Street", "Beech Avenue", "Dogwood Drive",
    "Fir Street", "Juniper Way", "Magnolia Street", "Poplar Street", "Redwood Road",
    "Sycamore Street", "Chestnut Street", "Hickory Avenue", "Alder Street", "Sequoia Way",
    "Cypress Street", "Locust Avenue", "Hemlock Street", "Ironwood Drive", "Linden Street",
    "Cedar Park", "Oak Knoll Drive", "Pine Needle Road", "Maplewood Drive", "Elmwood Avenue",
    "Rosewood Street", "Teakwood Drive", "Hawthorn Lane", "Myrtle Avenue", "Olive Branch Road",
    "Peachtree Street", "Bayberry Avenue", "Cedarwood Lane", "Daisy Street", "Elderberry Drive",
    "Fig Street", "Grove End Road", "High Street", "Ivy Road", "Jasmine Avenue"
	};
	
	static inline QStringList zipCode = {
	"10001", "10002", "10003", "10004", "10005",
    "10006", "10007", "10008", "10009", "10010",
    "10011", "10012", "10013", "10014", "10015",
    "10016", "10017", "10018", "10019", "10020",
    "10021", "10022", "10023", "10024", "10025",
    "10026", "10027", "10028", "10029", "10030",
    "10031", "10032", "10033", "10034", "10035",
    "10036", "10037", "10038", "10039", "10040",
    "10041", "10042", "10043", "10044", "10045",
    "10046", "10047", "10048", "10049", "10050"
	};

	static inline QStringList city = {
	"New York", "Los Angeles", "Chicago", "Houston", "Phoenix",
    "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose",
    "Austin", "Jacksonville", "Fort Worth", "Columbus", "Charlotte",
    "San Francisco", "Indianapolis", "Seattle", "Denver", "Washington",
    "Boston", "El Paso", "Detroit", "Nashville", "Portland",
    "Memphis", "Oklahoma City", "Las Vegas", "Louisville", "Baltimore",
    "Milwaukee", "Albuquerque", "Tucson", "Fresno", "Mesa",
    "Sacramento", "Atlanta", "Kansas City", "Colorado Springs", "Miami",
    "Raleigh", "Omaha", "Long Beach", "Virginia Beach", "Oakland",
    "Minneapolis", "Tulsa", "Arlington", "Tampa", "Tokyo"
	};

	static inline QStringList AreaCodes = {
	"205", "251", "659", "256", "334",
    "907", "480", "520", "602", "623",
    "928", "501", "479", "870", "209",
    "213", "310", "323", "408", "415",
    "510", "530", "559", "562", "619",
    "626", "650", "661", "707", "714",
    "760", "805", "818", "831", "858",
    "909", "916", "925", "949", "303",
    "719", "970", "203", "475", "860",
    "959", "302", "239", "305", "321",
    "352", "386", "407", "561", "689"
	};

public:
    static Contact createRandomContact();
};

#endif
