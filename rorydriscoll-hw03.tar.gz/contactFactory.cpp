#include "contactFactory.h"
#include "contact.h"
#include <QString>
#include <QTime>

Contact ContactFactory::createRandomContact() {
    int rndCat = qrand() % 10 + 1;
	QString rndFName = firstNames[qrand() % 50];
	QString rndLName = lastNames[qrand() % 50];
    QString rndSAdd = QString::number(qrand() % 999 + 1) + " " + streetAddresses[qrand() % 50];
	int area = qrand() % 50;
    QString rndZip = zipCode[area];
    QString rndCity = city[area];
    QString rndPhoneNum = "(" + AreaCodes[area] + ") " + QString::number(qrand() % 900 + 100) + " - " + QString::number(qrand()%9000 + 1000);
	return Contact(rndCat, rndFName, rndLName, rndSAdd, rndZip, rndCity, rndPhoneNum);

}
