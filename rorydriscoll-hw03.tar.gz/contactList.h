#ifndef CONTACTLIST_H
#define CONTACTLIST_H
#include "contact.h"
#include <QStringList>
#include <QList>

class ContactList : public QList<Contact> {
public:
	void add(Contact c);
	void remove(Contact C);
	QStringList getPhoneList(int category);
	QStringList getMailingList(int category);
	ContactList();
};

#endif
